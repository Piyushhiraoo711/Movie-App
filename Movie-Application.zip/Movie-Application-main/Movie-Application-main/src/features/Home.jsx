import React, { useEffect, useState } from "react";
import CarouselSlider from "../slider/CarouselSlider";
import SwiperSlider from "../slider/SwiperSlider";
import { useDispatch, useSelector } from "react-redux";
import { fetchMoviesByCategory } from "../slice/movieSlice";

const Home = () => {
  const [allMovies, setAllMovies] = useState([]);
  const dispatch = useDispatch();
  const currentuser = useSelector((state) => state.user.currentUser);
  const { popular, horror, comedy, loading } = useSelector(
    (state) => state.movies
  );

  useEffect(() => {
    dispatch(fetchMoviesByCategory("popular"));
    dispatch(fetchMoviesByCategory("horror"));
    dispatch(fetchMoviesByCategory("comedy"));
    getMovies();
  }, [dispatch]);

  if (loading) return <p>Loading...</p>;

  const getMovies = async () => {
    fetch("/data.json")
      .then((res) => res.json())
      .then((data) => {
        setAllMovies(data.Search);
      })
      .catch((err) => console.error("Error fetching movies:", err));
  };

  return (
    <>
      <div className="bg-black min-h-screen">
        <CarouselSlider movies={allMovies} />
      </div>
      <div>{console.log("popular", popular)}</div>
      <div className="bg-black min-h-screen text-white p-4">
        <SwiperSlider title="Popular Movies" movies={popular} />
        <SwiperSlider title="Comedy Movies" movies={comedy} />
        <SwiperSlider title="Horror Movies" movies={horror} />
      </div>
    </>
  );
};

export default Home;
