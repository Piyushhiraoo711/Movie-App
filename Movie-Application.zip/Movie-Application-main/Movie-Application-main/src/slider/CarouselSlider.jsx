import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const CarouselSlider = ({ movies }) => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 1500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    fade: true,
    arrows: false,
    pauseOnHover: false,
  };
  return (
    <div className="w-full h-[80vh] md:h-screen overflow-hidden bg-black text-white">
      {movies && movies.length > 0 ? (
        <Slider {...settings}>
          {movies.map((movie) => (
            <div
              key={movie.imdbID}
              className="relative w-full h-[80vh] md:h-screen mt-10"
            >
              <img
                src={movie.Poster}
                alt={movie.Title}
                className="w-full h-auto object-contain rounded-lg shadow-lg"
              />

              <div className="absolute inset-0 from-black via-black/40 to-transparent flex flex-col justify-end px-6 md:px-10 py-12">
                <h2 className="text-2xl md:text-5xl lg:text-6xl font-bold mb-4 leading-tight">
                  {movie.Title}
                </h2>
                <p className="max-w-2xl text-gray-300 text-sm md:text-base line-clamp-3">
                  {movie.Year}
                </p>

                {/* <div className="flex mt-6 gap-4">
                  <button className="bg-white text-black font-semibold px-4 py-2 rounded-md hover:bg-gray-300 transition">
                    ▶ Play
                  </button>
                  <button className="bg-gray-500/70 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition">
                    More Info
                  </button>
                </div> */}
              </div>
            </div>
          ))}
        </Slider>
      ) : (
        <p className="text-center mt-20 text-gray-400">Loading movies...</p>
      )}
    </div>
  );
};

export default CarouselSlider;
